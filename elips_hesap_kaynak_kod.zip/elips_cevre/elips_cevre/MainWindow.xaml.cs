﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Newtonsoft.Json;
using System.IO;
using System.Net;

namespace elips_cevre
{
    /// <summary>
    /// MainWindow.xaml etkileşim mantığı
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_sunucu_Click(object sender, RoutedEventArgs e)
        {
            if(textbox_boyut.Text != "")
            {
                bool dogrulama = false;
                string[] boyutlar = {"1", "2", "3", "4", "5"};
                for(int sayac = 0; sayac < 5; sayac++)
                {
                    if(textbox_boyut.Text == boyutlar[sayac])
                    {
                        dogrulama = true;
                        break;
                    }
                }
                if(dogrulama)
                {
                    string adres = "https://kutez.com/testapi/get_diameter.php?size=";
                    WebRequest istek = WebRequest.Create(adres + textbox_boyut.Text);
                    try
                    {
                        WebResponse cevap = istek.GetResponse();
                        StreamReader oku = new StreamReader(cevap.GetResponseStream());
                        String bilgi = oku.ReadToEnd();
                        elips parametreler = JsonConvert.DeserializeObject<elips>(bilgi);
                        if (parametreler.status == "success")
                        {
                            label_mesaj.Content = "Sunucuya erişim başarılı.";
                            label_mesaj.Foreground = Brushes.DarkGreen;
                            label_kucuk_cap.Content = parametreler.SmallDiameter;
                            label_buyuk_cap.Content = parametreler.BigDiameter;
                        }
                        else
                        {
                            MessageBox.Show("Sunucu bağlantı hatası.", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
                            label_mesaj.Content = "Sunucuya erişim başarısız.";
                            label_mesaj.Foreground = Brushes.DarkRed;
                            label_kucuk_cap.Content = parametreler.SmallDiameter;
                            label_buyuk_cap.Content = parametreler.BigDiameter;
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Sunucu bağlantı hatası.", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
                        label_mesaj.Content = "Sunucuya erişim başarısız.";
                        label_mesaj.Foreground = Brushes.DarkRed;
                    }
                    label_mesaj.Visibility = Visibility.Visible;
                }
                else
                {
                    MessageBox.Show("Boyut 1 - 5 arasında (1 ve 5 dahil) tamsayı olamalıdır.", "Bilgi", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("Herhangi bir bilezik boyutu belirtilmedi.", "Uyarı", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void textbox_kucuk_cap_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textbox_buyuk_cap_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
            {
                e.Handled= false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void button_cap_Click(object sender, RoutedEventArgs e)
        {
            if(button_cap.Content.ToString() == "Çapları Ayarla")
            {
                textbox_boyut.IsEnabled = false;
                button_sunucu.IsEnabled = false;
                label_mesaj.Visibility = Visibility.Hidden;
                label_kucuk_cap.Visibility = Visibility.Hidden;
                label_buyuk_cap.Visibility = Visibility.Hidden;
                label_cevre.Visibility = Visibility.Hidden;
                button_cap.Content = "Onayla";
                button_cap.Background = Brushes.Green;
                button_hesapla.Content = "İptal";
                button_hesapla.Background = Brushes.Red;
                textbox_kucuk_cap.Visibility = Visibility.Visible;
                textbox_buyuk_cap.Visibility= Visibility.Visible;
                textbox_kucuk_cap.Text = label_kucuk_cap.Content.ToString();
                textbox_buyuk_cap.Text = label_buyuk_cap.Content.ToString();
            }
            else
            {
                if(textbox_kucuk_cap.Text != "" && textbox_buyuk_cap.Text != "")
                {
                    if(Convert.ToInt32(textbox_kucuk_cap.Text) <= Convert.ToInt32(textbox_buyuk_cap.Text))
                    {
                        textbox_boyut.IsEnabled = true;
                        button_sunucu.IsEnabled = true;
                        label_kucuk_cap.Visibility = Visibility.Visible;
                        label_buyuk_cap.Visibility = Visibility.Visible;
                        label_kucuk_cap.Content = textbox_kucuk_cap.Text;
                        label_buyuk_cap.Content = textbox_buyuk_cap.Text;
                        button_cap.Content = "Çapları Ayarla";
                        BrushConverter renk = new BrushConverter();
                        button_cap.Background = (Brush)renk.ConvertFrom("#FFCA7B7B");
                        button_hesapla.Content = "Hesapla";
                        button_hesapla.Background = (Brush)renk.ConvertFrom("#FFA6BF9C");
                        textbox_kucuk_cap.Visibility = Visibility.Hidden;
                        textbox_buyuk_cap.Visibility= Visibility.Hidden;
                    }
                    else
                    {
                        MessageBox.Show("Küçük Çap, Büyük Çapa eşit veya küçük olabilir.", "Uyarı", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Küçük Çap veya Büyük Çap belirlenmemiş.", "Uyarı", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
        }

        private void button_hesapla_Click(object sender, RoutedEventArgs e)
        {
            if(button_hesapla.Content.ToString() == "İptal")
            {
                textbox_boyut.IsEnabled = true;
                button_sunucu.IsEnabled = true;
                label_kucuk_cap.Visibility = Visibility.Visible;
                label_buyuk_cap.Visibility = Visibility.Visible;
                button_cap.Content = "Çapları Ayarla";
                BrushConverter renk = new BrushConverter();
                button_cap.Background = (Brush)renk.ConvertFrom("#FFCA7B7B");
                button_hesapla.Content = "Hesapla";
                button_hesapla.Background = (Brush)renk.ConvertFrom("#FFA6BF9C");
                textbox_kucuk_cap.Visibility = Visibility.Hidden;
                textbox_buyuk_cap.Visibility = Visibility.Hidden;
            }
            else
            {
                if(label_kucuk_cap.Content.ToString() != "" && label_buyuk_cap.Content.ToString() != "")
                {
                    if(label_kucuk_cap.Content.ToString() != "0" && label_buyuk_cap.Content.ToString() != "0")
                    {
                        double h, kucuk_cap_yari, buyuk_cap_yari, cevre;
                        kucuk_cap_yari = Convert.ToDouble(label_kucuk_cap.Content.ToString()) / 2;
                        buyuk_cap_yari = Convert.ToDouble(label_buyuk_cap.Content.ToString()) / 2;
                        h = Math.Pow((buyuk_cap_yari - kucuk_cap_yari), 2) / Math.Pow((buyuk_cap_yari + kucuk_cap_yari), 2);
                        cevre = Math.PI * (buyuk_cap_yari + kucuk_cap_yari) * (1 + 3 * h / (10 + Math.Sqrt(4 - 3 * h)));
                        label_cevre.Content = Math.Round(cevre, 2);
                        label_cevre.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        MessageBox.Show("Küçük Çap ve Büyük Çap değerleri 0'dan büyük olmalı.", "Uyarı", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Küçük Çap ve Büyük Çap değerleri belirlenmemiş.", "Uyarı", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
        }
    }

    class elips
    {
        public string status { get; set; }
        public string SmallDiameter { get; set; }
        public string BigDiameter { get; set; }
    }
}
